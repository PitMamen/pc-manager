<template>
  <a-card
    :bordered="false"
    style="position: relative;height: calc(100% - 39px);background: #E8F3FF;"
  >
    <div>
      <img
        src="~@/assets/login/chahua.png"
        alt="logo"
        style="position: absolute;width: 425px;height: auto;top: 50%;left: 50%;transform: translate(-50%, -50%);"
      />
    </div>
  </a-card>
</template>

<script>
</script>

<style lang="less" scoped>
</style>
